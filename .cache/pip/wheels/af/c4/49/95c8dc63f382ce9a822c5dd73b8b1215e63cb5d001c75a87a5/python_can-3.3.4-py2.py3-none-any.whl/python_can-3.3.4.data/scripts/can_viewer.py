#!python
# coding: utf-8

"""
See :mod:`can.viewer`.
"""

from __future__ import absolute_import

from can.viewer import main


if __name__ == "__main__":
    main()
