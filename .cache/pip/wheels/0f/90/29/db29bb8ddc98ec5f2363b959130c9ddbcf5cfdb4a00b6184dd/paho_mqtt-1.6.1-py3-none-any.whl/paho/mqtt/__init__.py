__version__ = "1.6.1"


class MQTTException(Exception):
    pass
